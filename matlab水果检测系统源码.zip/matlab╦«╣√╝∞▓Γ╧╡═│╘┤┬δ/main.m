clc
clear all
close all
%cd('');
ii=imread('fruits2.jpg');
%figure,imshow(i);
i=ii;
[m,n,q]=size(i);
%%%��ɫת������
msgbox('�����ʦ΢�� matfun  ')

figure,imshow(i);
i=rgb2gray(i);
tt=graythresh(i);
i=im2bw(i,tt);
i= imfill(i,'hole');
%figure,imshow(i);
return
figure,imshow(i)
it=i;
[B,L]=bwboundaries(it,'noholes');
stats=regionprops(L,'all');
[L,num] = bwlabel(it); %���
figure,imshow(ii);
hold on
for i=1:num
    z(i)=stats(i).MajorAxisLength/stats(i).MinorAxisLength;
    %s(i)=stats(i).Area;
    %b(i)=stats(i).Eccentricity;
    %disp(b(i));
    if  z(i)<3
        rectangle('Position',[stats(i).BoundingBox],'EdgeColor','g');
    end
end